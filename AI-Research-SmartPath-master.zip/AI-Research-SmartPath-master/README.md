# AI-Research-SmartPath
####Research for Dr. Andrew Nuxoll
Building an agent to intelligently explore an unknown state machine using its
episodic memory to reduce the amount of work needed to reach the goal after each
successful run through the state machine.
